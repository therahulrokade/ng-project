import { Injectable } from "@angular/core";
import { Http, Response, Headers, RequestOptions } from "@angular/http";
import { Observable } from "rxjs";
import { Operator } from "src/app/models/app.operator.model";
import { Role } from "src/app/models/app.role.model";
import { User } from "src/app/models/app.user.model";

@Injectable()
export class DashboardService {
  url: string;

  constructor(private http: Http) {
    this.url = "http://localhost:4090";
  }

  CreateOperator(token: any, user: Operator): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.post(
      `${this.url}/api/createuser`,
      JSON.stringify(user),
      options
    );
    return resp;
  }

  getOperator(token: any): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.get(`${this.url}/api/getalluser`, options);
    return resp;
  }

  CreateRole(token: any, role: Role): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.post(
      `${this.url}/api/createrole`,
      JSON.stringify(role),
      options
    );
    return resp;
  }

  getRole(token: any): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.get(`${this.url}/api/getallroles`, options);
    return resp;
  }

  CreateUser(token: any, user: any, roleId: string): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token,
      Role: roleId
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.post(
      `${this.url}/api/createnormaluser`,
      JSON.stringify(user),
      options
    );
    return resp;
  }

  getUser(token: any): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.get(`${this.url}/api/getnormaluserinfo`, options);
    return resp;
  }

  getNormalUser(
    UserName: string,
    RoleId: string,
    token: any
  ): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token,
      UserName: UserName,
      RoleId: RoleId
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.get(`${this.url}/api/userbyid`, options);
    return resp;
  }

  getTempUser(token: any): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.get(`${this.url}/api/getalltempuser`, options);
    return resp;
  }

  getTempEditUser(token: any): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.get(`${this.url}/api/getalltempedituser`, options);
    return resp;
  }

  approveUser(token: any, user: any, roleId: string): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token,
      Role: roleId
    });

    let options: RequestOptions = new RequestOptions();
    options.headers = header;
    // alert(JSON.stringify(user));
    // console.log(`${this.url}/api/approveuser`);
    let resp: Observable<Response>;
    resp = this.http.post(
      `${this.url}/api/approveuser`,
      JSON.stringify(user),
      options
    );
    // alert(JSON.stringify(resp));
    return resp;
  }

  UpdateUser(token: any, user: any, roleId: string): Observable<Response> {
    let header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token,
      Role: roleId
    });
    let options: RequestOptions = new RequestOptions();
    options.headers = header;

    let resp: Observable<Response>;
    resp = this.http.put(
      `${this.url}/api/updateuser`,
      JSON.stringify(user),
      options
    );
    return resp;
  }
}
