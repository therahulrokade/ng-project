import { Injectable } from "@angular/core";
import {
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from "@angular/router";
import { CanActivate } from "@angular/router";
import { Observable } from "rxjs";

@Injectable()
export class AppGuard implements CanActivate {
  token: string;

  constructor(private router: Router) {
    this.token = sessionStorage.getItem("token");
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (this.token === null || undefined) {
      this.router.navigate(["login"]);
      return false;
    }
    return true;
  }
}
