import { Component, OnInit } from "@angular/core";
import { Role } from "src/app/models/app.role.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-create-role",
  templateUrl: "./create-role.component.html",
  styleUrls: ["./create-role.component.css"]
})
export class CreateRoleComponent implements OnInit {
  RoleID: string;
  RoleName: string;
  role: Role;
  roles: Array<Role>;
  tokenValue: string;

  constructor(private serv: DashboardService) {
    this.RoleID = "";
    this.RoleName = "";
    this.role = new Role("", "");
    this.roles = new Array<Role>();
    this.tokenValue = sessionStorage.getItem("token");
  }

  ngOnInit() {}

  clearRole(): void {
    this.role = new Role("", "");
  }

  saveRole(): void {
    this.serv.CreateRole(this.tokenValue, this.role).subscribe(
      (resp: Response) => {
        this.roles.push(resp.json().data);
        this.clearRole();
      },
      error => {
        console.log(`Error occured ${error}`);
      }
    );
  }
}
