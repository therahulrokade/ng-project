import { Component, OnInit } from "@angular/core";
import { Role } from "src/app/models/app.role.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-role-list",
  templateUrl: "./role-list.component.html",
  styleUrls: ["./role-list.component.css"]
})
export class RoleListComponent implements OnInit {
  tableHeaders: Array<string>;
  tokenValue: string;
  roles: Array<Role>;
  role: Role;

  constructor(private serv: DashboardService) {
    this.tokenValue = sessionStorage.getItem("token");
    this.roles = new Array<Role>();
    this.role = new Role("", "");
    this.tableHeaders = new Array<string>();
  }

  ngOnInit() {
    for (let o in this.role) {
      this.tableHeaders.push(o);
    }

    this.serv.getRole(this.tokenValue).subscribe(
      (resp: Response) => {
        this.roles = resp.json().data;
      },
      error => {
        console.log(`Error Occured ${error}`);
      }
    );
  }
}
