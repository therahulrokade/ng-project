import { Component, OnInit } from "@angular/core";
import { LoginService } from "src/services/app.user.login.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.css"]
})
export class ChangePasswordComponent implements OnInit {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
  UserName: string;
  roleId: string;
  tokenValue: string;
  message: string;
  password: string;

  constructor(private serv: LoginService) {
    this.oldPassword = "";
    this.newPassword = "";
    this.confirmPassword = "";
    this.UserName = sessionStorage.getItem("UserName");
    this.roleId = sessionStorage.getItem("roleId");
    this.tokenValue = sessionStorage.getItem("token");
    this.password = sessionStorage.getItem("pass");
    this.message = "";
  }

  ngOnInit() {}

  savePassword() {
    if (this.oldPassword === this.password) {
      if (this.newPassword === this.confirmPassword) {
        let userPassword = null;
        userPassword = {
          UserName: this.UserName,
          roleId: this.roleId,
          newPassword: this.newPassword
        };

        this.serv.changePassword(userPassword, this.tokenValue).subscribe(
          (resp: Response) => {
            //this.user = resp.json().data[0];
            //console.log(resp.json().data[0]);
          },
          error => {
            console.log(`Error Occured ${error}`);
          }
        );

        this.message = "Password changed Successfully";
        setTimeout(() => {
          this.message = " ";
        }, 2000);
        this.oldPassword = "";
        this.newPassword = "";
        this.confirmPassword = "";
      } else {
        this.message = "New Password and Confirm Password doesn't match";
        setTimeout(() => {
          this.message = " ";
        }, 2000);
        this.oldPassword = "";
        this.newPassword = "";
        this.confirmPassword = "";
      }
    } else {
      this.message = "Old Password doesn't match";
      setTimeout(() => {
        this.message = " ";
      }, 2000);
      this.oldPassword = "";
      this.newPassword = "";
      this.confirmPassword = "";
    }
  }
}
