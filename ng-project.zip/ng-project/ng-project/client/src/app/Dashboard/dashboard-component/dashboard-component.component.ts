import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-dashboard-component",
  templateUrl: "./dashboard-component.component.html",
  styleUrls: ["./dashboard-component.component.css"]
})
export class DashboardComponentComponent implements OnInit {
  UserName: string;
  RoleId: string;
  roleIdFlag: boolean = false;

  constructor(private _router: Router) {
    this.UserName = "";
    this.RoleId =
      sessionStorage.getItem("roleId") != null || undefined
        ? sessionStorage.getItem("roleId")
        : null;
  }

  ngOnInit() {
    if (this.RoleId === "1") {
      this.roleIdFlag = true;
    }
  }

  Logout() {
    this._router.navigate(["logout"]);
  }

  userName(): string {
    return sessionStorage.getItem("UserName") !== ""
      ? sessionStorage
          .getItem("UserName")
          .charAt(0)
          .toUpperCase() + sessionStorage.getItem("UserName").slice(1)
      : "";
  }
}
