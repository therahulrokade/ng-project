import { Component, OnInit } from "@angular/core";
import { Operator } from "src/app/models/app.operator.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-operator-list",
  templateUrl: "./operator-list.component.html",
  styleUrls: ["./operator-list.component.css"]
})
export class OperatorListComponent implements OnInit {
  tableHeaders: Array<string>;
  tokenValue: string;
  operators: Array<Operator>;
  operator: Operator;

  constructor(private serv: DashboardService) {
    this.tokenValue = sessionStorage.getItem("token");
    this.operators = new Array<Operator>();
    this.operator = new Operator(-1, "", "", "", "");
    this.tableHeaders = new Array<string>();
  }

  ngOnInit() {
    for (let o in this.operator) {
      this.tableHeaders.push(o);
    }

    this.serv.getOperator(this.tokenValue).subscribe(
      (resp: Response) => {
        this.operators = resp.json().data;
      },
      error => {
        console.log(`Error Occured ${error}`);
      }
    );
  }
}
