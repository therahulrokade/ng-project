import { Component, OnInit } from "@angular/core";
import { Operator, Operators } from "./../../../models/app.operator.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-create-operator",
  templateUrl: "./create-operator.component.html",
  styleUrls: ["./create-operator.component.css"]
})
export class CreateOperatorComponent implements OnInit {
  UserID: number;
  UserName: string;
  Password: string;
  Email: string;
  RoleId: string;
  allRoleId: number[];
  operator: Operator;
  tokenValue: string;
  operators: Array<Operator>;

  constructor(private serv: DashboardService) {
    this.UserID = this.randomXToY(1001, 1499);
    this.UserName = "";
    this.Password = "";
    this.Email = "";
    this.RoleId = "";
    this.allRoleId = [2, 3];
    this.operator = new Operator(this.UserID, "", "", "", "");
    this.operators = new Array<Operator>();
    this.tokenValue = sessionStorage.getItem("token");
  }

  ngOnInit() {}

  randomXToY(minVal, maxVal) {
    var randVal = minVal + Math.random() * (maxVal - minVal);
    return Math.round(randVal);
  }

  clearOperator(): void {
    this.operator = new Operator(this.UserID, "", "", "", "");
  }

  saveOperators(): void {
    this.serv.CreateOperator(this.tokenValue, this.operator).subscribe(
      (resp: Response) => {
        this.operators.push(resp.json().data);
        this.clearOperator();
      },
      error => {
        console.log(`Error occured ${error}`);
      }
    );
  }
}
