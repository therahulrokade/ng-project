import { Component, OnInit } from "@angular/core";
import { User } from "src/app/models/app.user.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.css"]
})
export class ProfileComponent implements OnInit {
  tokenValue: string;
  user: User;
  UserName: string;
  RoleId: string;
  genders: string[];
  IsPhysicalDisabilitys: string[];
  MaritatalStatus: string[];
  EducationStatus: string[];

  constructor(private serv: DashboardService) {
    this.tokenValue = sessionStorage.getItem("token");
    this.UserName = sessionStorage.getItem("UserName");
    this.RoleId = sessionStorage.getItem("roleId");
    this.genders = ["Male", "Female", "Others"];
    this.IsPhysicalDisabilitys = ["Yes", "NO"];
    this.MaritatalStatus = [
      "Married",
      "Unmarried",
      "Divorced",
      "Widow",
      "Widower"
    ];
    this.EducationStatus = [
      "Masters",
      "Phd",
      "Graduate",
      " Under-Graduate",
      "HSC",
      "SSC",
      "Illiterate"
    ];

    this.user = new User(
      -1,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      0,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    );
  }

  ngOnInit() {
    this.serv
      .getNormalUser(this.UserName, this.RoleId, this.tokenValue)
      .subscribe(
        (resp: Response) => {
          this.user = resp.json().data[0];
          console.log(resp.json().data[0]);
        },
        error => {
          console.log(`Error Occured ${error}`);
        }
      );
  }

  clearUser() {}

  saveUser() {}
}
