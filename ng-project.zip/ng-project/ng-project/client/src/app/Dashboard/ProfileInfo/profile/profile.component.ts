import { Component, OnInit } from "@angular/core";
import { User } from "src/app/models/app.user.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";
import { Router } from "@angular/router";

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.css"]
})
export class ProfileComponent implements OnInit {
  tokenValue: string;
  user: User;
  UserName: string;
  RoleId: string;
  genders: string[];
  IsPhysicalDisabilitys: string[];
  MaritatalStatus: string[];
  EducationStatus: string[];
  editFlag: boolean;
  oldData: User;
  message: string;
  buttonFlag: boolean;

  constructor(private serv: DashboardService, private _router: Router) {
    this.message = "";
    this.buttonFlag = false;
    this.tokenValue = sessionStorage.getItem("token");
    this.UserName = sessionStorage.getItem("UserName");
    this.RoleId = sessionStorage.getItem("roleId");
    this.genders = ["Male", "Female", "Others"];
    this.IsPhysicalDisabilitys = ["Yes", "NO"];
    this.MaritatalStatus = [
      "Married",
      "Unmarried",
      "Divorced",
      "Widow",
      "Widower"
    ];
    this.EducationStatus = [
      "Masters",
      "Phd",
      "Graduate",
      " Under-Graduate",
      "HSC",
      "SSC",
      "Illiterate"
    ];

    this.editFlag = false;

    this.user = new User(
      -1,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      0,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    );
  }

  ngOnInit() {
    this.serv
      .getNormalUser(this.UserName, this.RoleId, this.tokenValue)
      .subscribe(
        (resp: Response) => {
          this.user = resp.json().data[0];
          this.oldData = resp.json().data[0];
          //console.log(resp.json().data[0]);
        },
        error => {
          console.log(`Error Occured ${error}`);
        }
      );
  }

  editUser() {
    this.editFlag = true;
  }

  updateUser() {
    let user = null;
    user = {
      PersonalUniqueueID: this.user.UserID,
      FullName: `${this.user.FirstName}~${this.user.MiddleName}~${
        this.user.LastName
      }`,
      Gender: this.user.Gender,
      DateOfBirth: this.user.DateOfBirth,
      Age: this.user.Age,
      Address: `${this.user.flatno}~${this.user.societyname}~${
        this.user.streetname
      }`,
      City: this.user.City,
      State: this.user.State,
      PinCode: this.user.PinCode,
      PhoneNo: this.user.PhoneNo,
      MobileNo: this.user.MobileNo,
      Email: this.user.Email,
      PhysicalDisability: this.user.PhysicalDisability,
      MaritalStatus: this.user.MaritalStatus,
      EducationStatus: this.user.EducationStatus,
      BirthSign: this.user.BirthSign
    };

    if (JSON.stringify(this.user) === JSON.stringify(this.oldData)) {
      alert("You have to update your profile first!!!");
    } else {
      this.buttonFlag = true;
      this.serv.UpdateUser(this.tokenValue, user, this.RoleId).subscribe(
        (resp: Response) => {},
        error => {
          console.log(`Error occured ${error}`);
        }
      );
      this.user = this.oldData;
      this.editFlag = false;
      this.message = "Updation request send successfully!!!";
      setTimeout(() => {
        this.message = " ";
      }, 1200);
    }
  }

  cancle(): void {
    this.user = this.oldData;
    this.editFlag = false;
  }
}
