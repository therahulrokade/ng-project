import { Component, OnInit } from "@angular/core";
import { User } from "src/app/models/app.user.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-pending-user",
  templateUrl: "./pending-user.component.html",
  styleUrls: ["./pending-user.component.css"]
})
export class PendingUserComponent implements OnInit {
  tableHeaders: Array<string>;
  tokenValue: string;
  tempUsers: Array<User>;
  user: User;
  roleId: string;
  isAdmin: boolean;

  constructor(private serv: DashboardService) {
    this.tokenValue = sessionStorage.getItem("token");
    this.roleId = sessionStorage.getItem("roleId");
    this.tempUsers = new Array<User>();
    this.isAdmin = false;
    this.user = new User(
      -1,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      0,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    );
    this.tableHeaders = new Array<string>();
  }

  ngOnInit() {
    for (let o in this.user) {
      this.tableHeaders.push(o);
    }

    this.serv.getTempUser(this.tokenValue).subscribe(
      (resp: Response) => {
        this.tempUsers = resp.json().data;
      },
      error => {
        console.log(`Error Occured ${error}`);
      }
    );

    if (this.roleId === "1") {
      this.isAdmin = true;
    }
  }

  getSelectedUser(o: User): void {
    this.user = o;
    let tempUser = null;
    tempUser = {
      _id: this.user._id,
      PersonalUniqueueID: this.user.UserID,
      FullName: `${this.user.FirstName}~${this.user.MiddleName}~${
        this.user.LastName
      }`,
      Gender: this.user.Gender,
      DateOfBirth: this.user.DateOfBirth,
      Age: this.user.Age,
      Address: `${this.user.flatno}~${this.user.societyname}~${
        this.user.streetname
      }`,
      City: this.user.City,
      State: this.user.State,
      PinCode: this.user.PinCode,
      PhoneNo: this.user.PhoneNo,
      MobileNo: this.user.MobileNo,
      PhysicalDisability: this.user.PhysicalDisability,
      MaritalStatus: this.user.MaritalStatus,
      EducationStatus: this.user.EducationStatus,
      BirthSign: this.user.BirthSign
    };

    this.serv.approveUser(this.tokenValue, tempUser, this.roleId).subscribe(
      (resp: Response) => {
        //this.roles.push(resp.json().data);
        alert(resp.json().data);
      },
      error => {
        console.log(`Error occured ${error}`);
      }
    );
  }

  rejectUser(o: User): void {
    this.user = o;
  }
}
