import { Component, OnInit } from "@angular/core";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";
import { User } from "./../../../models/app.user.model";

@Component({
  selector: "app-create-user",
  templateUrl: "./create-user.component.html",
  styleUrls: ["./create-user.component.css"]
})
export class CreateUserComponent implements OnInit {
  PersonalUniqueueID: number;
  firstname: string;
  middlename: string;
  lastname: string;
  dob: string;
  age: string;
  flatno: string;
  societyname: string;
  streetname: string;
  city: string;
  state: string;
  pincode: string;
  phoneno: string;
  mobileno: string;
  birthsign: string;
  gender: string;
  IsPhysicalDisability: string;

  MaritatalSelectedStatus: string;
  EducationalSelectedStatus: string;
  genders: string[];
  IsPhysicalDisabilitys: string[];
  MaritatalStatus: string[];
  EducationStatus: string[];
  user: User;
  users: Array<User>;
  tokenValue: string;

  constructor(private serv: DashboardService) {
    this.users = new Array<User>();
    this.tokenValue = sessionStorage.getItem("token");
    this.PersonalUniqueueID = this.randomXToY(1, 999);
    this.firstname = "";
    this.middlename = "";
    this.lastname = "";
    this.dob = "";
    this.age = "";
    this.flatno = "";
    this.societyname = "";
    this.streetname = "";
    this.city = "";
    this.state = "";
    this.pincode = "";
    this.phoneno = "";
    this.mobileno = "";
    this.birthsign = "";
    this.gender = "";
    this.IsPhysicalDisability = "";

    this.MaritatalSelectedStatus = "";
    this.EducationalSelectedStatus = "";
    this.genders = ["Male", "Female", "Others"];
    this.IsPhysicalDisabilitys = ["Yes", "NO"];
    this.MaritatalStatus = [
      "Married",
      "Unmarried",
      "Divorced",
      "Widow",
      "Widower"
    ];
    this.EducationStatus = [
      "Masters",
      "Phd",
      "Graduate",
      " Under-Graduate",
      "HSC",
      "SSC",
      "Illiterate"
    ];
  }

  ngOnInit() {}

  randomXToY(minVal, maxVal) {
    var randVal = minVal + Math.random() * (maxVal - minVal);
    return Math.round(randVal);
  }

  clearUser(): void {
    this.user = new User(
      this.randomXToY(1001, 1499),
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      0,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    );
  }

  saveUser(): void {
    let user = null;
    user = {
      PersonalUniqueueID: this.PersonalUniqueueID,
      FullName: `${this.firstname}~${this.middlename}~${this.lastname}`,
      Gender: this.gender,
      DateOfBirth: this.dob,
      Age: this.age,
      Address: `${this.flatno}~${this.societyname}~${this.streetname}`,
      City: this.city,
      State: this.state,
      PinCode: this.pincode,
      PhoneNo: this.phoneno,
      MobileNo: this.mobileno,
      PhysicalDisability: this.IsPhysicalDisability,
      MaritalStatus: this.MaritatalSelectedStatus,
      EducationStatus: this.EducationalSelectedStatus,
      BirthSign: this.birthsign
    };

    this.serv.CreateUser(this.tokenValue, user).subscribe(
      (resp: Response) => {
        this.users.push(resp.json().data);
        this.clearUser();
      },
      error => {
        console.log(`Error occured ${error}`);
      }
    );
  }
}
