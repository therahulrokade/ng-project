import { Component, OnInit } from "@angular/core";
import { User } from "src/app/models/app.user.model";
import { DashboardService } from "src/services/app.dashboard.service";
import { Response } from "@angular/http";

@Component({
  selector: "app-user-list",
  templateUrl: "./user-list.component.html",
  styleUrls: ["./user-list.component.css"]
})
export class UserListComponent implements OnInit {
  tableHeaders: Array<string>;
  tokenValue: string;
  users: Array<User>;
  user: User;

  constructor(private serv: DashboardService) {
    this.tokenValue = sessionStorage.getItem("token");
    this.users = new Array<User>();
    this.user = new User(
      -1,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      0,
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    );
    this.tableHeaders = new Array<string>();
  }

  ngOnInit() {
    for (let o in this.user) {
      this.tableHeaders.push(o);
    }

    this.serv.getUser(this.tokenValue).subscribe(
      (resp: Response) => {
        this.users = resp.json().data;
      },
      error => {
        console.log(`Error Occured ${error}`);
      }
    );
  }
}
