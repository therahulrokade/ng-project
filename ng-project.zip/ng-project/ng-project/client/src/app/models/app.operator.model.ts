export class Operator {
  constructor(
    public UserID: number,
    public UserName: string,
    public Password: string,
    public Email: string,
    public RoleId: string
  ) {}
}

export const Operators: Array<Operator> = new Array<Operator>();
