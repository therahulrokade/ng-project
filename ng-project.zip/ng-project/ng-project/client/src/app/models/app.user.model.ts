export class User {
  constructor(
    public UserID: number,
    public FirstName: string,
    public MiddleName: string,
    public LastName: string,
    public Gender: string,
    public DateOfBirth: string,
    public Age: string,
    public City: string,
    public State: string,
    public PinCode: number,
    public PhoneNo: string,
    public MobileNo: string,
    public BirthSign: string,
    public flatno: string,
    public societyname: string,
    public streetname: string,
    public _id: string,
    public PhysicalDisability: string,
    public MaritalStatus: string,
    public EducationStatus: string
  ) {}
}

export const Users: Array<User> = new Array<User>();
