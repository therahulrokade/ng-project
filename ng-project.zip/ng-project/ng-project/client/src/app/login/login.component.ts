import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Response } from "@angular/http";
import { LoginService } from "./../../services/app.user.login.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  UserName: string;
  Password: string;
  message: string;

  constructor(private _router: Router, private serv: LoginService) {
    this.UserName = "";
    this.Password = "";
    this.message = "";
    this.UserName = "";
  }

  ngOnInit() {}

  loginUser(): void {
    this.serv.authanticateUser(this.UserName, this.Password).subscribe(resp => {
      this.message = resp.json().message;
      if (resp.json().statusCode === 200) {
        // this.userauth.isUserAuthenticated(resp.json().authenticated);
        // this.isActive = resp.json().authenticated;
        //console.log(resp.json());

        sessionStorage.setItem("token", resp.json().token);
        sessionStorage.setItem("UserName", resp.json().UserName);
        sessionStorage.setItem("roleId", resp.json().roleId);
        setTimeout(() => {
          this._router.navigate(["dashboard"]);
        }, 600);
      } else {
        this.message = "Incorrect UserName or Password.";
        setTimeout(() => {
          this.message = " ";
        }, 1200);
        this.UserName = "";
        this.Password = "";
      }
    });
  }
}
