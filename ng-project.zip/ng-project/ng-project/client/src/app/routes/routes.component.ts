import { RouterModule, Routes } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";
import { LoginComponent } from "./../login/login.component";
import { DashboardComponentComponent } from "../Dashboard/dashboard-component/dashboard-component.component";
import { CreateRoleComponent } from "./../Dashboard/Role/create-role/create-role.component";
import { RoleListComponent } from "../Dashboard/Role/role-list/role-list.component";
import { CreateOperatorComponent } from "../Dashboard/Operator/create-operator/create-operator.component";
import { OperatorListComponent } from "../Dashboard/Operator/operator-list/operator-list.component";
import { CreateUserComponent } from "../Dashboard/User/create-user/create-user.component";
import { UserListComponent } from "../Dashboard/User/user-list/user-list.component";
import { PendingUserComponent } from "../Dashboard/pending-user/pending-user.component";
import { LogoutComponent } from "../logout/logout/logout.component";

const routes: Routes = [
  {
    path: "",

    redirectTo: "login",

    pathMatch: "full"
  },
  {
    path: "login",

    component: LoginComponent
  },
  {
    path: "dashboard",
    component: DashboardComponentComponent,
    children: [
      { path: "createrole", component: CreateRoleComponent },
      { path: "rolelist", component: RoleListComponent },
      { path: "createoperator", component: CreateOperatorComponent },
      { path: "operatorlist", component: OperatorListComponent },
      { path: "createuser", component: CreateUserComponent },
      { path: "userlist", component: UserListComponent },
      { path: "pendinglist", component: PendingUserComponent }
    ]
  },
  {
    path: "logout",
    component: LogoutComponent
  },
  {
    path: "**",

    component: LoginComponent
  }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
