import { RouterModule, Routes } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";
import { LoginComponent } from "./../login/login.component";
import { DashboardComponentComponent } from "../Dashboard/dashboard-component/dashboard-component.component";
import { CreateRoleComponent } from "./../Dashboard/Role/create-role/create-role.component";
import { RoleListComponent } from "../Dashboard/Role/role-list/role-list.component";
import { CreateOperatorComponent } from "../Dashboard/Operator/create-operator/create-operator.component";
import { OperatorListComponent } from "../Dashboard/Operator/operator-list/operator-list.component";
import { CreateUserComponent } from "../Dashboard/User/create-user/create-user.component";
import { UserListComponent } from "../Dashboard/User/user-list/user-list.component";
import { PendingUserComponent } from "../Dashboard/Approvals/pending-user/pending-user.component";
import { LogoutComponent } from "../logout/logout/logout.component";
import { AppGuard } from "./../../services/app.guard.service";
import { ProfileComponent } from "../Dashboard/ProfileInfo/profile/profile.component";
import { ChangePasswordComponent } from "../Dashboard/change-password/change-password.component";
import { EditApprovalComponent } from "../Dashboard/Approvals/edit-approval/edit-approval.component";

const routes: Routes = [
  {
    path: "",

    redirectTo: "login",

    pathMatch: "full"
  },
  {
    path: "login",

    component: LoginComponent
  },
  {
    path: "dashboard",
    component: DashboardComponentComponent,
    children: [
      {
        path: "createrole",
        component: CreateRoleComponent,
        canActivate: [AppGuard]
      },
      {
        path: "rolelist",
        component: RoleListComponent,
        canActivate: [AppGuard]
      },
      {
        path: "createoperator",
        component: CreateOperatorComponent,
        canActivate: [AppGuard]
      },
      {
        path: "operatorlist",
        component: OperatorListComponent,
        canActivate: [AppGuard]
      },
      {
        path: "createuser",
        component: CreateUserComponent,
        canActivate: [AppGuard]
      },
      {
        path: "userlist",
        component: UserListComponent,
        canActivate: [AppGuard]
      },
      {
        path: "pendinglist",
        component: PendingUserComponent,
        canActivate: [AppGuard]
      },
      {
        path: "profile",
        component: ProfileComponent,
        canActivate: [AppGuard]
      },
      {
        path: "password",
        component: ChangePasswordComponent,
        canActivate: [AppGuard]
      },
      {
        path: "editapproval",
        component: EditApprovalComponent,
        canActivate: [AppGuard]
      }
    ]
  },
  {
    path: "logout",
    component: LogoutComponent
  },
  {
    path: "**",

    component: LoginComponent
  }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
