import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpModule } from "@angular/http";

import { routing } from "./routes/routes.component";
//import { AppRoutingModule } from "./m";
import { AppComponent } from "./app.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { LoginComponent } from "./login/login.component";
import { DashboardComponentComponent } from "./Dashboard/dashboard-component/dashboard-component.component";
import { CreateRoleComponent } from "./Dashboard/Role/create-role/create-role.component";
import { RoleListComponent } from "./Dashboard/Role/role-list/role-list.component";
import { CreateOperatorComponent } from "./Dashboard/Operator/create-operator/create-operator.component";
import { OperatorListComponent } from "./Dashboard/Operator/operator-list/operator-list.component";
import { UserListComponent } from "./Dashboard/User/user-list/user-list.component";
import { PendingUserComponent } from "./Dashboard/Approvals/pending-user/pending-user.component";
import { CreateUserComponent } from "./Dashboard/User/create-user/create-user.component";
import { LoginService } from "src/services/app.user.login.service";
import { LogoutComponent } from "./logout/logout/logout.component";
import { DashboardService } from "./../services/app.dashboard.service";
import { AppGuard } from "./../services/app.guard.service";
import { ProfileComponent } from "./Dashboard/ProfileInfo/profile/profile.component";
import { ChangePasswordComponent } from "./Dashboard/change-password/change-password.component";
import { EditApprovalComponent } from "./Dashboard/Approvals/edit-approval/edit-approval.component";

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponentComponent,
    CreateRoleComponent,
    RoleListComponent,
    CreateOperatorComponent,
    OperatorListComponent,
    UserListComponent,
    PendingUserComponent,
    CreateUserComponent,
    LogoutComponent,
    ProfileComponent,
    ChangePasswordComponent,
    EditApprovalComponent
  ],
  imports: [BrowserModule, routing, FormsModule, HttpModule],
  providers: [LoginService, DashboardService, AppGuard],
  bootstrap: [AppComponent]
})
export class AppModule {}
