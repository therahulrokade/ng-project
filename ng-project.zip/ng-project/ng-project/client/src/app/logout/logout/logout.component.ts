import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

@Component({
  selector: "app-logout",
  templateUrl: "./logout.component.html",
  styleUrls: ["./logout.component.css"]
})
export class LogoutComponent implements OnInit {
  constructor(private _router: Router) {
    // var token = sessionStorage.getItem("token");
    // if (token !== undefined || token !== null) {
    //   //sessionStorage.removeItem("token");
    //   token = null;
    //   sessionStorage.setItem("token", token);
    // }
  }

  ngOnInit() {
    sessionStorage.clear();
    this._router.navigate(["login"]);
  }
}
