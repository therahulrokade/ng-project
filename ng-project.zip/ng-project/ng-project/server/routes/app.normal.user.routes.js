var express = require("express");
var router = express.Router();

var NormalUserController = require("../controllers/normal.user.controller");

//Normal User CRUD Operations

router.get("/api/getnormaluserinfo", function(req, res) {
  NormalUserController.GetAllNormalUserInfo(req, res);
});

router.post("/api/createnormaluser", function(req, res) {
  NormalUserController.Create(req, res);
});

router.put("/api/updateuser", function(req, res) {
  NormalUserController.Update(req, res);
});

router.delete("/api/deletenormaluser/:id", function(req, res) {
  NormalUserController.Delete(req, res);
});

router.get("/api/getalltempuser", function(req, res) {
  NormalUserController.GetAllTempUser(req, res);
});

router.get("/api/getalltempedituser", function(req, res) {
  NormalUserController.GetAllTempEditUser(req, res);
});

router.post("/api/approveuser", function(req, res) {
  NormalUserController.Approve(req, res);
});

router.get("/api/userbyid", function(req, res) {
  NormalUserController.GetUserById(req, res);
});

// router.get("/api/searchoperator", function(req, res) {
//   NormalUserController.SearchOperator(req, res);
// });

module.exports = router;
