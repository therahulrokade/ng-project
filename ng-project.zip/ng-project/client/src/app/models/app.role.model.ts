export class Role {
  constructor(public RoleID: string, public RoleName: string) {}
}

export const Roles: Array<Role> = new Array<Role>();
