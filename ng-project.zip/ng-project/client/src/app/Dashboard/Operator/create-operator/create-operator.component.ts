import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-operator',
  templateUrl: './create-operator.component.html',
  styleUrls: ['./create-operator.component.css']
})
export class CreateOperatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
