import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operator-list',
  templateUrl: './operator-list.component.html',
  styleUrls: ['./operator-list.component.css']
})
export class OperatorListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
