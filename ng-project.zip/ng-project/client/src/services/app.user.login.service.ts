import { Injectable } from "@angular/core";
import { Http, Response, Headers, RequestOptions } from "@angular/http";
import { Observable } from "rxjs";

@Injectable()
export class LoginService {
  url: string;

  constructor(private http: Http) {
    this.url = "http://localhost:4090";
  }

  authanticateUser(UserName: string, Password: string): Observable<Response> {
    var user = {
      UserName: UserName,
      Password: Password
    };

    let resp: Observable<Response>;
    resp = this.http.post(`${this.url}/api/userlogin`, user);
    return resp;
  }
}
